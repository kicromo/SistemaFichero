//#include <linux/linkage.h>
//#include <linux/wait_bit.h>
#include <linux/kdev_t.h>
//#include <linux/dcache.h>
//#include <linux/path.h>
#include <linux/stat.h>
//#include <linux/cache.h>
//#include <linux/list.h>
//#include <linux/list_lru.h>
//#include <linux/llist.h>
//#include <linux/radix-tree.h>
//#include <linux/xarray.h>
//#include <linux/rbtree.h>
//#include <linux/init.h>
//#include <linux/pid.h>
//#include <linux/bug.h>
//#include <linux/mutex.h>
//#include <linux/rwsem.h>
//#include <linux/mm_types.h>
#include <linux/capability.h>
//#include <linux/semaphore.h>
#include <linux/fcntl.h>
//#include <linux/rculist_bl.h>
//#include <linux/atomic.h>
//#include <linux/shrinker.h>
//#include <linux/migrate_mode.h>
//#include <linux/uidgid.h>
//#include <linux/lockdep.h>
//#include <linux/percpu-rwsem.h>
//#include <linux/workqueue.h>
//#include <linux/delayed_call.h>
#include <linux/uuid.h>
//#include <linux/errseq.h>
#include <linux/ioprio.h>
//#include <linux/fs_types.h>
//#include <linux/build_bug.h>
#include <linux/stddef.h>
#include <linux/mount.h>
//#include <linux/cred.h>
//#include <linux/mnt_idmapping.h>
//#include <linux/slab.h>
#include <asm/byteorder.h>
#include <linux/fs.h>
#include <linux/path.h>
#include <linux/types.h>
#include "implementation.h"
#include <stdlib.h>


//typedef struct super_operations *pt_super_operations;
//ypedef struct inode   *L_idonde;

struct inode *(*alloc_inode)(struct super_block *sb){                       /*inode -> asignar memoria*/
    T_inode nuevo;
    nuevo = malloc (sizeof(struct inode));
    nuevo->inode =  
    struct super_block ptd;

}

void (*free_inode)(struct inode *){/*free_inode*/

}








