#include "implementation.h"


int main (){

    T_super_block raiz;
    T_inode nodo;
    raiz->s_op->alloc_inode(&raiz);     // para crear memoria en inodo
    raiz->s_op->free_inode(nodo);
    
    super_block arbol = null;
    pt_super_block->s_op->alloc_inode;
    //pt_super_block->s_blocksize_bytes = 512;
    pt_super_block->s_active = 0;                   // false
    pt_super_block->s_blocksize = 512;
    return 0;


}
